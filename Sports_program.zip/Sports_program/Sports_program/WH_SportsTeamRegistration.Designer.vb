﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSportsRegistration
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grpSportoptions = New System.Windows.Forms.GroupBox()
        Me.radBasketball = New System.Windows.Forms.RadioButton()
        Me.radSoccer = New System.Windows.Forms.RadioButton()
        Me.radFootball = New System.Windows.Forms.RadioButton()
        Me.lblNumberofplayers = New System.Windows.Forms.Label()
        Me.txtPot = New System.Windows.Forms.TextBox()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.txtTotal = New System.Windows.Forms.TextBox()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.grpSportoptions.SuspendLayout()
        Me.SuspendLayout()
        '
        'grpSportoptions
        '
        Me.grpSportoptions.Controls.Add(Me.radBasketball)
        Me.grpSportoptions.Controls.Add(Me.radSoccer)
        Me.grpSportoptions.Controls.Add(Me.radFootball)
        Me.grpSportoptions.Location = New System.Drawing.Point(44, 54)
        Me.grpSportoptions.Name = "grpSportoptions"
        Me.grpSportoptions.Size = New System.Drawing.Size(240, 141)
        Me.grpSportoptions.TabIndex = 0
        Me.grpSportoptions.TabStop = False
        Me.grpSportoptions.Text = "Sport Options"
        '
        'radBasketball
        '
        Me.radBasketball.AutoSize = True
        Me.radBasketball.Location = New System.Drawing.Point(20, 100)
        Me.radBasketball.Name = "radBasketball"
        Me.radBasketball.Size = New System.Drawing.Size(98, 25)
        Me.radBasketball.TabIndex = 2
        Me.radBasketball.TabStop = True
        Me.radBasketball.Text = "Basketball"
        Me.radBasketball.UseVisualStyleBackColor = True
        '
        'radSoccer
        '
        Me.radSoccer.AutoSize = True
        Me.radSoccer.Location = New System.Drawing.Point(20, 69)
        Me.radSoccer.Name = "radSoccer"
        Me.radSoccer.Size = New System.Drawing.Size(74, 25)
        Me.radSoccer.TabIndex = 1
        Me.radSoccer.TabStop = True
        Me.radSoccer.Text = "Soccer"
        Me.radSoccer.UseVisualStyleBackColor = True
        '
        'radFootball
        '
        Me.radFootball.AutoSize = True
        Me.radFootball.Location = New System.Drawing.Point(20, 38)
        Me.radFootball.Name = "radFootball"
        Me.radFootball.Size = New System.Drawing.Size(84, 25)
        Me.radFootball.TabIndex = 0
        Me.radFootball.TabStop = True
        Me.radFootball.Text = "Football"
        Me.radFootball.UseVisualStyleBackColor = True
        '
        'lblNumberofplayers
        '
        Me.lblNumberofplayers.AutoSize = True
        Me.lblNumberofplayers.Location = New System.Drawing.Point(403, 92)
        Me.lblNumberofplayers.Name = "lblNumberofplayers"
        Me.lblNumberofplayers.Size = New System.Drawing.Size(140, 21)
        Me.lblNumberofplayers.TabIndex = 1
        Me.lblNumberofplayers.Text = "Number of Players"
        '
        'txtPot
        '
        Me.txtPot.Location = New System.Drawing.Point(407, 122)
        Me.txtPot.Name = "txtPot"
        Me.txtPot.Size = New System.Drawing.Size(135, 29)
        Me.txtPot.TabIndex = 2
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(86, 283)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(139, 61)
        Me.btnCalculate.TabIndex = 3
        Me.btnCalculate.Text = "&Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(309, 283)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(123, 59)
        Me.btnClear.TabIndex = 4
        Me.btnClear.Text = "&Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'txtTotal
        '
        Me.txtTotal.BackColor = System.Drawing.SystemColors.GrayText
        Me.txtTotal.Location = New System.Drawing.Point(427, 188)
        Me.txtTotal.Name = "txtTotal"
        Me.txtTotal.ReadOnly = True
        Me.txtTotal.Size = New System.Drawing.Size(100, 29)
        Me.txtTotal.TabIndex = 5
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(516, 285)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(123, 59)
        Me.btnClose.TabIndex = 7
        Me.btnClose.Text = "&Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'frmSportsRegistration
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 21.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.HotTrack
        Me.ClientSize = New System.Drawing.Size(714, 394)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.txtTotal)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.txtPot)
        Me.Controls.Add(Me.lblNumberofplayers)
        Me.Controls.Add(Me.grpSportoptions)
        Me.Font = New System.Drawing.Font("Ebrima", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Name = "frmSportsRegistration"
        Me.Text = "Sports Team Registration"
        Me.grpSportoptions.ResumeLayout(False)
        Me.grpSportoptions.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents grpSportoptions As GroupBox
    Friend WithEvents radBasketball As RadioButton
    Friend WithEvents radSoccer As RadioButton
    Friend WithEvents radFootball As RadioButton
    Friend WithEvents lblNumberofplayers As Label
    Friend WithEvents txtPot As TextBox
    Friend WithEvents btnCalculate As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents txtTotal As TextBox
    Friend WithEvents btnClose As Button
End Class
